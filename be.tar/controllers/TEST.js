const m2test = require('./booking');

(async () => {
    let 
})();