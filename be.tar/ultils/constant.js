exports.users = [
    {
        email: 'user1@gmail.com',
        password: 123456,
        firstName: 'aa',
        lastName: 'aa',
        mobile: '0123456789'
    },
    {
        email: 'user2@gmail.com',
        password: 123456,
        firstName: 'bb',
        lastName: 'bb',
        mobile: '0123456788'
    },
    {
        email: 'user3@gmail.com',
        password: 123456,
        firstName: 'cc',
        lastName: 'cc',
        mobile: '0123456787'
    },
    {
        email: 'user4@gmail.com',
        password: 123456,
        firstName: 'dd',
        lastName: 'dd',
        mobile: '0123456786'
    },
]
