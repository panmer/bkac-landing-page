const router = require('express').Router()
// const ctrls = require('../controllers/insertData')


// router.post('/', ctrls.insertProduct)
// router.post('/cate', ctrls.insertCategory)
// router.post('/cate_service', ctrls.insertCategoryService)
module.exports = router