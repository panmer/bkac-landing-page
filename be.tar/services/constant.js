module.exports = {
    SERVICES: "datnhk241services",
    BLOGS: "datnhk241blogs",
    PROVIDERS: "datnhk241providers",
    HEALTH_STATUS_TIMEOUT: "2s",
    ELASTIC_URL: 'http://localhost:9200'
}
/*
DISABLE ELASTIC SECURITY:
xpack.security.enabled: false
xpack.security.transport.ssl.enabled: false
xpack.security.http.ssl.enabled: false
*/
